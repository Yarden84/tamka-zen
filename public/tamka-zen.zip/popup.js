document.addEventListener('DOMContentLoaded', function() {
    const zenModeToggle = document.getElementById('zenToggle');
    const statusDiv = document.getElementById('status');

    // Check if current page is a Ynet article
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        chrome.tabs.sendMessage(tabs[0].id, {action: "checkYnetArticle"}, function(response) {
            const isYnetArticle = response && response.isYnetArticle;
            zenModeToggle.disabled = !isYnetArticle;
            
            if (!isYnetArticle) {
                statusDiv.textContent = "Not available on this page";
                zenModeToggle.checked = false;
            } else {
                // Always start with Zen mode off
                zenModeToggle.checked = false;
                updateStatus(false);
            }
        });
    });

    // Handle toggle changes
    zenModeToggle.addEventListener('change', function() {
        const isEnabled = zenModeToggle.checked;
        
        // Send message to content script
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
            chrome.tabs.sendMessage(tabs[0].id, {action: "toggleZenMode"}, function(response) {
                if (response && response.message) {
                    statusDiv.textContent = response.message;
                } else {
                    updateStatus(isEnabled);
                }
            });
        });
    });

    function updateStatus(isEnabled) {
        statusDiv.textContent = isEnabled ? 
            "Zen mode is active - related articles are hidden" : 
            "Zen mode is inactive - related articles are visible";
    }
}); 